package com.arnab.maven.Bicycle.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.arnab.maven.Bicycle.model.Bicycle;
import com.arnab.maven.Bicycle.service.BicycleService;

@RestController
public class BicycleController {

	@Autowired
	BicycleService bikeService;
	
	
	@RequestMapping(value = "/{id}" , method = RequestMethod.GET)
	
	
	public Bicycle getBicycle(@PathVariable(name = "id"),int id) {
		
		return bikeService.getBicycle(id);
	}
}
