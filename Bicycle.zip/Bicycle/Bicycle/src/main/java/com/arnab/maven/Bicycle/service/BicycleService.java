package com.arnab.maven.Bicycle.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.arnab.maven.Bicycle.model.Bicycle;

@Service
public class BicycleService {

	
	@Autowired
	BicycleDao bikeDao;
	
	public Bicycle getBicycle(int id) {
		
		Bicycle bicycle = bikeDao.getBicycle(id);
	}
	
	public List<Bicycle> getAllBicycles(){
		
		return bikedao.getAllBicycles();
	}

}
